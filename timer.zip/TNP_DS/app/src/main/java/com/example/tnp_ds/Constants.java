package com.example.tnp_ds;

public class Constants {
    public static final String QUESTION_NUM = "question_number";
    public static final String QUESTION_QUES = "questions";
    public static final String FORMATED ="formated";
}
