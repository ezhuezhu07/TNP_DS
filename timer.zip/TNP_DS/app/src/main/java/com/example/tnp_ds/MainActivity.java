package com.example.tnp_ds;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void quiz(View view)
    {
        Intent intent=new Intent(this,Quiztnp.class);
        startActivity(intent);
    }
    public void ans(View view)
    {
        Intent intent=new Intent(this,Answertnp.class);
        startActivity(intent);
    }
    public void db (View view)
    {
        Intent intent=new Intent(this,base.class);
        startActivity(intent);
    }
}
