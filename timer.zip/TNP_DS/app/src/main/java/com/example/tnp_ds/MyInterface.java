package com.example.tnp_ds;

public interface MyInterface
{
    void copy(String txt);
    void ques(String quest);
}