package com.example.tnp_ds;

public class QandA {
    String Qid;
    String Qno;
    String Qques;
    String Qans;

    public QandA(String qid, String qno, String qques, String qans) {
        Qid = qid;
        Qno = qno;
        Qques = qques;
        Qans = qans;
    }

    public String getQid() {
        return Qid;
    }

    public String getQno() {
        return Qno;
    }

    public String getQques() {
        return Qques;
    }

    public String getQans() {
        return Qans;
    }
}
