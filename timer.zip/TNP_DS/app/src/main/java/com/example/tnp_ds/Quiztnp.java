package com.example.tnp_ds;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;


import static com.example.tnp_ds.Constants.FORMATED;

public class Quiztnp  extends AppCompatActivity
{

    public static TextView time;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiztnp);
        time=findViewById(R.id.timer);
        Intent intent = new Intent(Quiztnp.this, Timer.class);
        intent.putExtra("sleepTime", 0);
        startService(intent);
       // time.setText(Timer.formated);

    }

}

