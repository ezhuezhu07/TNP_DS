package com.example.tnp_ds;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import java.util.Locale;

public class Timer extends Service   {

    private static final String TAG = Timer.class.getSimpleName();
    public static String formated;
    @Override
    public void onCreate() {
        super.onCreate();

        Log.i(TAG, "onCreate, Thread name " + Thread.currentThread().getName());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Log.i(TAG, "onStartCommand, Thread name " + Thread.currentThread().getName());

        // Perform Tasks [ Short Duration Task: Don't block the UI ]

        int sleepTime = intent.getIntExtra("sleepTime", 1800);

        new MyAsyncTask().execute(sleepTime);

        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {

        Log.i(TAG, "onBind, Thread name " + Thread.currentThread().getName());
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        Log.i(TAG, "onDestroy, Thread name " + Thread.currentThread().getName());
    }

    // AsyncTask class declaration
    @SuppressLint("StaticFieldLeak")
    class MyAsyncTask extends AsyncTask<Integer, String, Void> {
        private final String TAG = MyAsyncTask.class.getSimpleName();
        private TextView time;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            Log.i(TAG, "onPreExecute, Thread name " + Thread.currentThread().getName());
        }

        @Override // Perform our Long Running Task
        protected Void doInBackground(Integer... params) {
            Log.i(TAG, "doInBackground, Thread name " + Thread.currentThread().getName());

            int sleepTime = params[0];
            int ctr = 1800;
            while(ctr >= sleepTime) {
                publishProgress(""+ctr);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                ctr--;
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            int minutes = Integer.parseInt(values[0]) / 60;
            int seconds=Integer.valueOf(values[0])%60;
            formated= String.format(Locale.getDefault(),"%02d:%02d", minutes,seconds);
           /* public void val(String formated)
            {
                Formated =formated;
            }*/
            //TextView time=(TextView) findViewById(R.id.timer);
            Quiztnp.time.setText(formated);

            Toast.makeText(Timer.this, formated, Toast.LENGTH_SHORT).show();
            Log.i(TAG, "Counter Value " + values[0]+ " onProgressUpdate, Thread name " + Thread.currentThread().getName());
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            stopSelf(); // Destroy the Service from within the Service class itself
            Log.i(TAG, "onPostExecute, Thread name " + Thread.currentThread().getName());

        }
    }
}
