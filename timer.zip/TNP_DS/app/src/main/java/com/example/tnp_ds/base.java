package com.example.tnp_ds;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.w3c.dom.Text;

public class base extends AppCompatActivity {
    private EditText value1,value2,value3;
    private Button add;
    public FirebaseDatabase fire;
    DatabaseReference databaseQanda;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base);
        fire = FirebaseDatabase.getInstance();
        databaseQanda =fire.getReference("qandA");
        value1 = findViewById(R.id.qno);
        value2 = findViewById(R.id.ques);
        value3 = findViewById(R.id.ans);
        add = findViewById(R.id.addfb);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addQuestion();
            }
        });
    }

    private void addQuestion()
    {
        String n = value1.getText().toString().trim();
        String q = value2.getText().toString();
        String a = value3.getText().toString();
        if(!TextUtils.isEmpty(n) || !TextUtils.isEmpty(q) ||!TextUtils.isEmpty(a))
        {
            String id = databaseQanda.push().getKey();
            QandA qandA = new QandA(id,n,q,a);
            databaseQanda.child(id).setValue(qandA);
        }
        else
        {
            Toast.makeText(this,"You must enter question num",Toast.LENGTH_LONG).show();
        }
    }
}
