package com.example.tnp_ds;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class first extends Fragment {
    private TextView text;
    public String ans;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        if (savedInstanceState == null) {
            View view = inflater.inflate(R.layout.fragment_first, container, false);

            text = view.findViewById(R.id.text2);
            Bundle bundle = getArguments();
            final String Ques = bundle.getString(Constants.QUESTION_QUES, "");
            switch (Ques)
            {
                case "1.What is data structures?":
                    ans="Data Structure is a particular way of organising data in a computer so that it can be used effectively.";
                    break;
                case "2.What are the types of data structures?":
                    ans="Linear Data Structure.\nNon Linear Data Structure.";
                    break;
                case "3.What is linear data structure?":
                    ans="A data structure is called linear if all of its elements are arranged in the sequential order. In linear data structures, the elements are stored in a non-hierarchical way where each item has the successors and predecessors except the first and last element.";
                    break;
                case  "4.What is non linear data structure?":
                    ans="The Non-linear data structure does not form a sequence i.e. each item or element is connected with two or more other items in a non-linear arrangement. The data elements are not arranged in the sequential structure.";
                    break;
            }
            text.setText(ans);
            String s = (String) text.getText();
            MyInterface myInterface = (MyInterface) getActivity();
            myInterface.copy(s);
            return  view;
        }
        return null;
    }

}
