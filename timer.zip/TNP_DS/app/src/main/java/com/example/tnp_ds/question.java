package com.example.tnp_ds;



import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class question extends Fragment {
    private  String q;
    private TextView textView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v =inflater.inflate(R.layout.fragment_question, container, false);
        textView = v.findViewById(R.id.textview);
        Bundle bundle = getArguments();
        final int question_number = bundle.getInt(Constants.QUESTION_NUM, 1);
        if(question_number>=1)
        {


            switch (question_number)
            {
                case 1:
                    q = "1.What is data structures?";
                    break;
                case 2:
                    q="2.What are the types of data structures?";
                    break;
                case 3:
                    q="3.What is linear data structure?";
                    break;
                case 4 :
                    q="4.What is non linear data structure?";
                    break;
            }
        }
        MyInterface myInterface = (MyInterface) getActivity();
        myInterface.ques(q);
        textView.setText(q);
        return v;
    }



}
